$(document).ready(function() {
    $(".logo").fadeTo(1400, 1);
    $(".inner_txt_me").delay(400).fadeTo(1200, 1);
    $(".lSSlideWrapper").delay(1000).fadeTo(1200, 1);
    $(".lSPager").delay(1600).fadeTo(1200, 1);
    $(".comp_bg").delay(2000).fadeTo(1200, 1);
});